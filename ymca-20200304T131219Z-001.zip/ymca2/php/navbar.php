<?php

echo '
<header class="sopra">
	<nav>
    <h1 id="logo">Liviana<span>PC</span></h1>
    <ul>
      <li><a href="index.php" title="">Home</a></li>
       <li><a href="vetrina.php" title="">Vetrina</a></li>
       <li><a href="about.php" title="">Contatti</a></li>
    </ul>
  </nav>
</header>
';


?>