<?php 


echo '<footer class="footer-distributed">

<div class="footer-right">

    <a href="#" class="fa fa-facebook"></a>
    <a href="#"><i class="fab fa-twitter"></i></a>
    <a href="#"><i class="fab fa-linkedin"></i></a>
    <a href="#"><i class="fab fa-github"></i></a>

</div>

<div class="footer-left">

    <p class="footer-links">
        <a class="link-1" href="index.php">Home</a>

        <a class="link-1" href="./php/vetrina.php">Vetrina</a>

        <a class="link-1" href="./php/vetrina.php">Contatti</a>
    </p>

    <p>Liviana &copy; 2020</p>
</div>

</footer>';?>